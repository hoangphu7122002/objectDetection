import os

path = "/Users/guest/Desktop/HoangPhu/Vehicle_Detection/objectDetection/FacenetDataset/Phong"
dirs = os.listdir(path)

for i,file in enumerate(dirs):
    if '.py' not in file:
        os.rename(file,'{}.jpg'.format(i + 1))
